# 17-Day Code Index

Start with `README.md`, then follow day folders in order.

## Day 01: Initialize project and sample CSV
- Task: Create folders, environment, README, and a tiny synthetic dataset.
- Commit: `chore: initialize CAN IDS project structure`
- Instructions: `day_01/README.md`

## Day 02: Inspect CSV schema and validate fields
- Task: Inspect columns, count rows, labels, missing values, CAN ID format, DLC and payload examples.
- Commit: `data: add CAN dataset inspection and schema validation`
- Instructions: `day_02/README.md`

## Day 03: Normalize and validate CAN records
- Task: Use the shared parser to normalize timestamps, IDs, DLC and payload bytes.
- Commit: `feat: implement CAN traffic preprocessing`
- Instructions: `day_03/README.md`

## Day 04: Extract timing and payload features
- Task: Compute inter-arrival time, per-ID rate, payload sum and byte diversity.
- Commit: `feat: extract temporal and CAN ID features`
- Instructions: `day_04/README.md`

## Day 05: Configure baseline detection rules
- Task: Review default thresholds and tune against known-normal data.
- Commit: `feat: add configurable CAN anomaly rules`
- Instructions: `day_05/README.md`

## Day 06: Build the core detection engine
- Task: Run rule checks and return alerts with explainable reason codes.
- Commit: `feat: implement core detection engine`
- Instructions: `day_06/README.md`

## Day 07: Add unit tests
- Task: Test parsers, rate rules, and low-rate normal traffic.
- Commit: `test: add detection engine unit tests`
- Instructions: `day_07/README.md`

## Day 08: Optional ML baseline
- Task: Only if labels are available: train a simple Decision Tree/Random Forest baseline; keep it separate from rules.
- Commit: `feat: add baseline CAN attack classifier`
- Instructions: `day_08/README.md`

## Day 09: Evaluate the detector
- Task: Compute precision, recall, F1 and confusion matrix on held-out labeled data.
- Commit: `feat: add model evaluation metrics`
- Instructions: `day_09/README.md`

## Day 10: Review false positives/negatives
- Task: Inspect alert samples and adjust thresholds only using a validation split.
- Commit: `test: evaluate false positives and false negatives`
- Instructions: `day_10/README.md`

## Day 11: Standardize alert schema
- Task: Ensure alert rows contain timestamp, CAN ID, severity and reason codes.
- Commit: `feat: add structured security alerts`
- Instructions: `day_11/README.md`

## Day 12: Export detection reports
- Task: Write results to CSV and keep private/raw data out of version control.
- Commit: `feat: export CAN IDS detection reports`
- Instructions: `day_12/README.md`

## Day 13: Add command-line interface
- Task: Run the engine with input/output paths and configurable rate thresholds.
- Commit: `feat: add command line analysis interface`
- Instructions: `day_13/README.md`

## Day 14: Integrate team interfaces
- Task: Agree column names and output contract with parameter/feature and dashboard members.
- Commit: `test: integrate end-to-end detection pipeline`
- Instructions: `day_14/README.md`

## Day 15: Improve reliability/performance
- Task: Handle bad input, large files and repeated runs; document constraints.
- Commit: `perf: improve CAN traffic processing reliability`
- Instructions: `day_15/README.md`

## Day 16: Document setup and limitations
- Task: Document installation, schema, rules, evaluation and known limitations.
- Commit: `docs: document CAN IDS setup and usage`
- Instructions: `day_16/README.md`

## Day 17: Final smoke test and handover
- Task: Run all tests, run the sample CSV, inspect diff, create a tagged release if approved.
- Commit: `release: finalize 17-day CAN IDS prototype`
- Instructions: `day_17/README.md`
