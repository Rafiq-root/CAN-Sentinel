# Calendar and deadline

Project window: **10 November 2026 through 10 December 2026**. Deadline remains **10 December 2026**.

- Day 1 = 10 Nov
- Day 2 = 11 Nov
- Day 3 = 12 Nov
- Day 4 = 13 Nov
- Day 5 = 14 Nov
- Day 6 = 15 Nov
- Day 7 = 16 Nov
- Day 8 = 17 Nov
- Day 9 = 18 Nov
- Day 10 = 19 Nov
- Day 11 = 20 Nov
- Day 12 = 21 Nov
- Day 13 = 22 Nov
- Day 14 = 23 Nov
- Day 15 = 24 Nov
- Day 16 = 25 Nov
- Day 17 = 26 Nov

Days 18–30 (27 Nov–9 Dec): integration with other members, code review, fixes, test on approved data, demo rehearsal, and final handover.  
10 Dec: final deadline / submission. No deadline extension is assumed.

The plan has 17 engine-focused implementation days inside the 30-day project window. It does not mean the whole team project is finished after 17 days.
